# Project 1: EC 530
## Continuous Intergration & Continuous Development

The purpose of this project is to learn tools such as pytest, flake8, and git hub actions.

*requirements.txt* contains the necessary imports to fully run this project.

*MatrixMult.py* contains the functions that conducts the matrix multiplication.

*test_MatrixMult.py* contains the test created for a variety of cases in matrix multiplication.

[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/5WunfJN-)
